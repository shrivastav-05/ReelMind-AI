from pathlib import Path
import joblib, pandas as pd, numpy as np
from flask import Flask, render_template, request, redirect, url_for, session
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.tree import DecisionTreeClassifier

BASE=Path(__file__).resolve().parent
DATA=BASE/"data"/"heart.csv"
MODEL=BASE/"models"/"heart_disease_pipeline.pkl"
app=Flask(__name__)
app.secret_key="heart-predictor-local-session-key"
FEATURES=["Age","Sex","ChestPainType","RestingBP","Cholesterol","FastingBS","RestingECG","MaxHR","ExerciseAngina","Oldpeak","ST_Slope"]
OPTIONS={"Sex":{"M","F"},"ChestPainType":{"TA","ATA","NAP","ASY"},"FastingBS":{"0","1"},"RestingECG":{"Normal","ST","LVH"},"ExerciseAngina":{"N","Y"},"ST_Slope":{"Up","Flat","Down"}}

def validate(form):
    v={k:form.get(k,"").strip() for k in FEATURES}
    for k,x in v.items():
        if not x: raise ValueError(f"Please fill in {k}.")
    for k,allowed in OPTIONS.items():
        if v[k] not in allowed: raise ValueError(f"Invalid option for {k}.")
    for k in ["Age","RestingBP","Cholesterol","FastingBS","MaxHR"]: v[k]=int(v[k])
    v["Oldpeak"]=float(v["Oldpeak"])
    if not 1<=v["Age"]<=120: raise ValueError("Age must be between 1 and 120.")
    if min(v["RestingBP"],v["Cholesterol"],v["MaxHR"])<0: raise ValueError("Numeric health values cannot be negative.")
    return v

def train_model():
    df=pd.read_csv(DATA); X=df.drop(columns=["HeartDisease"]); y=df["HeartDisease"]
    nums=X.select_dtypes(include=np.number).columns.tolist()
    cats=X.select_dtypes(exclude=np.number).columns.tolist()
    Xt, Xv, yt, yv=train_test_split(X,y,test_size=.20,random_state=42,stratify=y)
    num=Pipeline([("imputer",SimpleImputer(strategy="median")),("scaler",StandardScaler())])
    cat=Pipeline([("imputer",SimpleImputer(strategy="most_frequent")),("encoder",OneHotEncoder(handle_unknown="ignore"))])
    prep=ColumnTransformer([("numeric",num,nums),("categorical",cat,cats)])
    model=Pipeline([("preprocessor",prep),("classifier",DecisionTreeClassifier(random_state=42))])
    model.fit(Xt,yt); MODEL.parent.mkdir(exist_ok=True); joblib.dump(model,MODEL)

def predict(v):
    if not MODEL.exists(): raise FileNotFoundError("Saved model not found. Choose Train a New Model.")
    model=joblib.load(MODEL); row={k:v[k] for k in FEATURES}
    X=pd.DataFrame([row],columns=FEATURES); pred=int(model.predict(X)[0]); prob=None
    if hasattr(model,"predict_proba"):
        probs=model.predict_proba(X)[0]; classes=list(model.classes_)
        if 1 in classes: prob=float(probs[classes.index(1)])*100
    return pred,prob

@app.get("/")
def home(): return render_template("index.html",values={},error=None)

@app.post("/choose-method")
def choose_method():
    try:
        session["form_values"]=validate(request.form)
        return render_template("choose_method.html",error=None)
    except (ValueError,TypeError) as e:
        return render_template("index.html",values=request.form,error=str(e)),400

@app.post("/predict-existing")
def predict_existing():
    v=session.get("form_values")
    if not v: return redirect(url_for("home"))
    try:
        pred,prob=predict(v); session["result"]={"prediction":pred,"probability":prob,"method":"Existing Saved Model"}
        return redirect(url_for("result"))
    except Exception as e:
        return render_template("choose_method.html",error=str(e)),400

@app.post("/train-new")
def train_new():
    v=session.get("form_values")
    if not v: return redirect(url_for("home"))
    try:
        train_model(); pred,prob=predict(v)
        session["result"]={"prediction":pred,"probability":prob,"method":"Newly Trained Model"}
        return redirect(url_for("result"))
    except Exception as e:
        return render_template("choose_method.html",error=f"Training/prediction failed: {e}"),500

@app.get("/result")
def result():
    r=session.get("result")
    if not r: return redirect(url_for("home"))
    r=dict(r); r["label"]="Higher-risk pattern predicted" if r["prediction"]==1 else "Lower-risk pattern predicted"
    return render_template("result.html",result=r)

@app.post("/again")
def again():
    session.clear(); return redirect(url_for("home"))

if __name__=="__main__": app.run(debug=True)
