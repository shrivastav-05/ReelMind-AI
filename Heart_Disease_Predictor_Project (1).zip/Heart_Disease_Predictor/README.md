# Heart Disease Predictor

## Application flow
1. Fill the Heart Disease form and click **Continue to Prediction Method**.
2. Choose **Use Existing Model** for a quick prediction, or **Train New Model** to retrain using `data/heart.csv`.
3. View the final prediction result with the method used and buttons to return home or predict again.

The form values are preserved between the form and method selection using a Flask session. The app does not show training configuration controls, Data Split Preview, information buttons, or a separate training-loading page.

## Project structure
```text
Heart_Disease_Predictor/
├── app.py
├── Heart_Disease_Predictor.ipynb
├── requirements.txt
├── README.md
├── data/heart.csv
├── models/heart_disease_pipeline.pkl
├── templates/
│   ├── index.html
│   ├── choose_method.html
│   └── result.html
└── static/heart.css
```

## Run on Windows
```powershell
python -m pip install -r requirements.txt
python app.py
```
Open `http://127.0.0.1:5000`.

Training uses a fixed stratified 80:20 train/test split. This project is for education only, not medical diagnosis or treatment decisions.
